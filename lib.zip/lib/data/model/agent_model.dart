
class AgentModel {
  final String name;
  final String number;

  AgentModel( {required this.name,required this.number});
}

List<AgentModel> dummyAgent = [
  AgentModel(name: 'Jhone walker due', number: '+8801717123456'),
  AgentModel(name: 'Jhone walker due', number: '+8801717123456'),
  AgentModel(name: 'Jhone walker due', number: '+8801717123456')
];