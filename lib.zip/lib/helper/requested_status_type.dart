enum RequestedMoneyStatusType {
  pending,
  approved,
  sellerProduct,
  denied,
  all
}