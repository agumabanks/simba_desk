import 'package:flutter/material.dart';

class BalanceInputShimmer extends StatelessWidget {
  const BalanceInputShimmer({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(

    );
  }
}
