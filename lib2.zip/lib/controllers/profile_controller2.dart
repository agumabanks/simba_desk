import 'package:get/get.dart';
import 'package:simbadesketop/models/profiles_model.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart';
// import 'package:get/get.dart';
// import 'package:http/http.dart' as http;
// import 'package:simbadesketop/models/profiles_model.dart';


class ProfileController extends GetxController implements GetxService{

  var userList = <Profiles>[].obs;

  List<Profiles>? _profiles;

  List<Profiles>? get profilesList => _profiles;


  // @override
  // void onInit() {
  //   fetchUsers();
  //   super.onInit();
  // }
  Future<void> getProfiles(bool reload) async{
    if(reload){
      final response =
        await http.get(Uri.parse('http://159.89.80.33:8080/getallusers'));
        if(response.body == 200){
          _profiles =[];
        
          var decodedData = jsonDecode(response.body) as List;
          _profiles!.assignAll(decodedData.map((e) => Profiles.fromJson(e)));


        }
        update();
        print(_profiles![1].userId);
    }
  }

  void fetchUsers() async {
    final response =
        await http.get(Uri.parse('http://159.89.80.33:8080/getallusers'));
    if (response.statusCode == 200) {
      var decodedData = jsonDecode(response.body) as List;
      userList.assignAll(decodedData.map((e) => Profiles.fromJson(e)));
      
      print(userList[1].userId);
      print(userList[2].userId);
      
      // print(decodedData);
          // final profiles = profilesFromJson(response.body);
          
          // print(profiles[1].userId);// return profiles;

      
    } else {
      if (kDebugMode) {
        print('Failed to fetch users');
      }
    }
  }
}