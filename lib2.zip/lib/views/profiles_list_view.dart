import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:simbadesketop/controllers/profiles_controller.dart';

class UserListView extends StatelessWidget {
  final ProfilesController userController = Get.put(ProfilesController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('User List')),
      body: Center(
        child: Obx(
          () => ListView.builder(
            itemCount: userController.userList.length,
            itemBuilder: (_, index) {
              return ListTile(
                title: Text("userController.userList[index].firstName.toString()"),
                subtitle: Text(userController.userList[index].gender.toString()),
              );
            },
          ),
        ),
      ),
    );
  }
}
